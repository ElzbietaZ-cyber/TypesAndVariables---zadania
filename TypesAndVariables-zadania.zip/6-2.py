###
# A program that prints your initials
#
name = 'Elżbieta'
surname = 'Zawadzka'
print(name[0] + surname[0])