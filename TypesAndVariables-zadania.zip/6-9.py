###
# Character code conversion
# Write a program that allows you to check what word is hidden in the following character codes:
# 67, 111, 111, 108, 33

print(chr(67),chr(111),chr(111),chr(108),chr(33))