###
# Printing student's personal data
#
name = "Adam"
age =  20
height = 175
print(f"My name is {name}.")
print(f"I am {age} years old, and my height is {height} cm.")
print(f"In 6 years I will be {age + 6 } years old.  ")