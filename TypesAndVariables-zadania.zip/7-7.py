import random
random_number = random.randint(5,10)
print(random_number)