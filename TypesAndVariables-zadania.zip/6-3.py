###
# A program that prints a university abbreviation
#   
university = "Krakow University of Economics"
abbrevation = university[0] + university[7] + university[21]
print(abbrevation)