###
# Calculation of circle area and circumference 
#

# determine radius and PI values
# calculate area 
# calculate circumference 
# print results

PI = 3.14
radius = float(input("Provide the lenght of the radius: "))
area = PI * radius**2
circumference = 2 * PI * radius 
print(f"The area is {area}")
print(f"The circumference is: {circumference}")
