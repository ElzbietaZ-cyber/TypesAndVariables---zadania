###
# A program that, for a given speed in km/h,
# prints the speed in m/s
#
speed_kmh = 70
speed_ms = (speed_kmh*1000)/3600
print("km/h = ", speed_kmh, "to ", "m/s =", speed_ms)
