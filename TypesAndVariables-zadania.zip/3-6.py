import math
h = float(input("the height of the observer in meters: "))
d = 3.57 * math.sqrt(h)
print("The distance to the horizon in kilometers:", d)
